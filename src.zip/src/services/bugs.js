import API from "./api";

/**
 * BUGS SERVICE (ADMIN WEB)
 * Padronizado para /admin/bugs
 */

async function safeGet(url, options) {
  try {
    const res = await API.get(url, options);
    return res.data;
  } catch (err) {
    if (err.response?.status === 404) {
      return [];
    }
    throw err;
  }
}

/**
 * Lista bugs (ADMIN)
 */
export async function getBugs(params = {}) {
  return safeGet("/admin/bugs", { params });
}

/**
 * Busca bug por ID (ADMIN)
 */
export async function getBugById(id) {
  if (!id) return null;
  return safeGet(`/admin/bugs/${id}`);
}

/**
 * Métricas de bugs (ADMIN)
 */
export async function getBugMetrics() {
  return safeGet("/admin/bugs/metrics");
}
