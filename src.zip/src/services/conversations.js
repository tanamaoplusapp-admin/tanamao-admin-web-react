import API from "./api";

/**
 * CONVERSATIONS SERVICE (ADMIN WEB)
 * Padronizado para /admin/conversations
 */

async function safeGet(url, options) {
  try {
    const res = await API.get(url, options);
    return res.data;
  } catch (err) {
    if (err.response?.status === 404) {
      return [];
    }
    throw err;
  }
}

/**
 * Lista conversas (ADMIN)
 */
export async function getConversations(params = {}) {
  return safeGet("/admin/conversations", { params });
}

/**
 * Busca conversa por ID (ADMIN)
 */
export async function getConversationById(id) {
  if (!id) return null;
  return safeGet(`/admin/conversations/${id}`);
}

/**
 * Mensagens da conversa (ADMIN)
 */
export async function getConversationMessages(conversationId) {
  if (!conversationId) return [];
  return safeGet(`/admin/conversations/${conversationId}/messages`);
}

/**
 * Enviar mensagem como ADMIN
 */
export async function sendConversationMessage(conversationId, message) {
  if (!conversationId || !message) return null;

  const res = await API.post(
    `/admin/conversations/${conversationId}/messages`,
    {
      message,
      from: "admin",
    }
  );

  return res.data;
}
