import { createBrowserRouter } from "react-router-dom";
import Login from "./pages/Login";
import RequireAdmin from "./auth/RequireAdmin";
import AdminLayout from "./layout/AdminLayout";

import Dashboard from "./pages/Dashboard";
import Orders from "./pages/Orders";
import Users from "./pages/Users";
import Conversations from "./pages/Conversations";
import Finance from "./pages/Finance";
import Bugs from "./pages/Bugs";
import Audit from "./pages/Audit";

export const router = createBrowserRouter([
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/",
    element: (
      <RequireAdmin>
        <AdminLayout />
      </RequireAdmin>
    ),
    children: [
      { index: true, element: <Dashboard /> },
      { path: "orders", element: <Orders /> },

      // 🔒 PAGE ÚNICA DE USUÁRIOS
      { path: "users", element: <Users /> },
      { path: "finance/users", element: <Users /> },

      { path: "conversations", element: <Conversations /> },
      { path: "finance", element: <Finance /> },
      { path: "bugs", element: <Bugs /> },
      { path: "audit", element: <Audit /> },
    ],
  },
]);
