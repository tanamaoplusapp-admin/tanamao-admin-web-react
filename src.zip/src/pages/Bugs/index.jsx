import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getBugs } from "../../services/bugs";

export default function Bugs() {
  const navigate = useNavigate();

  const [bugs, setBugs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function load() {
      try {
        const data = await getBugs();
        setBugs(data || []);
      } catch (err) {
        setError(
          err.response?.data?.message ||
            err.message ||
            "Erro ao carregar bugs"
        );
      } finally {
        setLoading(false);
      }
    }

    load();
  }, []);

  if (loading) {
    return <div style={page}>Carregando bugs…</div>;
  }

  if (error) {
    return <div style={page}>{error}</div>;
  }

  return (
    <div style={page}>
      <h2 style={title}>Bugs & Falhas</h2>
      <p style={subtitle}>
        Erros capturados no app, backend e operações críticas
      </p>

      <div style={tableWrapper}>
        <table style={table}>
          <thead>
            <tr>
              <th style={th}>Tipo</th>
              <th style={th}>Severidade</th>
              <th style={th}>Status</th>
              <th style={th}>Origem</th>
              <th style={th}>Última ocorrência</th>
              <th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {bugs.map((b) => (
              <tr key={b.id || b._id}>
                <td style={td}>{b.type || "—"}</td>
                <td
                  style={{
                    ...td,
                    fontWeight: 700,
                    color:
                      b.severity === "critical"
                        ? "#DC2626"
                        : b.severity === "medium"
                        ? "#92400E"
                        : "#15803D",
                  }}
                >
                  {b.severity || "—"}
                </td>
                <td style={td}>{b.status || "open"}</td>
                <td style={td}>{b.source || "—"}</td>
                <td style={td}>
                  {b.lastSeen
                    ? new Date(b.lastSeen).toLocaleString()
                    : "—"}
                </td>
                <td style={{ ...td, textAlign: "right" }}>
                  <button
                    onClick={() =>
                      navigate(`/bugs/${b.id || b._id}`)
                    }
                    style={btn}
                  >
                    Ver detalhe
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {bugs.length === 0 && (
          <div style={{ padding: 20 }}>
            Nenhum bug registrado ainda.
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= STYLES ================= */

const page = {
  background: "#F9FAFB",
  color: "#111827",
  minHeight: "100vh",
  padding: 24,
};

const title = {
  fontSize: 22,
  fontWeight: 900,
  color: "#14532D",
};

const subtitle = {
  marginBottom: 20,
  color: "#4B5563",
};

const tableWrapper = {
  background: "#FFFFFF",
  border: "1px solid #E5E7EB",
  borderRadius: 12,
  overflow: "hidden",
};

const table = {
  width: "100%",
  borderCollapse: "collapse",
};

const th = {
  padding: 12,
  textAlign: "left",
  fontSize: 13,
  fontWeight: 700,
  background: "#F3F4F6",
  color: "#374151",
};

const td = {
  padding: 12,
  borderTop: "1px solid #E5E7EB",
  fontSize: 14,
  color: "#111827",
};

const btn = {
  background: "#14532D",
  color: "#FFFFFF",
  border: "none",
  padding: "6px 12px",
  borderRadius: 8,
  fontWeight: 700,
  cursor: "pointer",
};
