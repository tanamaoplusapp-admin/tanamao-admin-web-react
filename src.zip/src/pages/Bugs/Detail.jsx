import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Page from "../../layout/Page";
import { getBugById } from "../../services/bugs";

export default function BugDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [bug, setBug] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function load() {
      try {
        const data = await getBugById(id);
        setBug(data);
      } catch (err) {
        setError(
          err.response?.data?.message ||
            err.message ||
            "Erro ao carregar bug"
        );
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [id]);

  if (loading) {
    return <Page title="Bug">Carregando bug…</Page>;
  }

  if (error) {
    return <Page title="Bug">{error}</Page>;
  }

  if (!bug) {
    return <Page title="Bug">Bug não encontrado</Page>;
  }

  return (
    <Page title="Detalhe do Bug">
      <button onClick={() => navigate("/bugs")} style={backBtn}>
        ← Voltar
      </button>

      <div style={card}>
        <Info label="Tipo" value={bug.type} />
        <Info label="Severidade" value={bug.severity} />
        <Info label="Status" value={bug.status} />
        <Info label="Origem" value={bug.source} />
        <Info
          label="Última ocorrência"
          value={
            bug.lastSeen
              ? new Date(bug.lastSeen).toLocaleString()
              : "—"
          }
        />

        <Divider />

        <Info label="Mensagem" value={bug.message || "—"} pre />
        <Info label="Stack / Contexto" value={bug.stack || "—"} pre />

        <Divider />

        <Info
          label="Usuário afetado"
          value={bug.user?.email || "—"}
        />
        <Info
          label="Recorrência"
          value={
            bug.count ? `${bug.count} ocorrências` : "—"
          }
        />
      </div>
    </Page>
  );
}

/* ================= COMPONENTS ================= */

function Info({ label, value, pre }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <strong>{label}</strong>
      <div
        style={{
          marginTop: 4,
          whiteSpace: pre ? "pre-wrap" : "normal",
          background: pre ? "#F3F4F6" : "transparent",
          padding: pre ? 12 : 0,
          borderRadius: pre ? 8 : 0,
          fontSize: 14,
        }}
      >
        {value}
      </div>
    </div>
  );
}

function Divider() {
  return (
    <div
      style={{
        height: 1,
        background: "#E5E7EB",
        margin: "16px 0",
      }}
    />
  );
}

/* ================= STYLES ================= */

const backBtn = {
  background: "transparent",
  border: "none",
  color: "#14532D",
  fontWeight: 700,
  marginBottom: 16,
  cursor: "pointer",
};

const card = {
  background: "#FFFFFF",
  border: "1px solid #E5E7EB",
  borderRadius: 12,
  padding: 20,
  maxWidth: 720,
};
