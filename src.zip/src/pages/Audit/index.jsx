import { useEffect, useState } from "react";
import API from "../../services/api";

export default function Audit() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const res = await API.get("/admin/audit");
      setLogs(res.data?.data || []);
      setLoading(false);
    }
    load();
  }, []);

  return (
    <div style={{ padding: 24 }}>
      <h1 style={{ fontSize: 24, fontWeight: 900 }}>Auditoria</h1>
      <p style={{ color: "#64748B" }}>Ações administrativas registradas</p>

      {loading && <p>Carregando…</p>}

      {!loading && (
        <table style={{ width: "100%", marginTop: 20 }}>
          <thead>
            <tr>
              <th>Admin</th>
              <th>Ação</th>
              <th>Alvo</th>
              <th>Quando</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((l) => (
              <tr key={l._id}>
                <td>{l.adminId?.name}</td>
                <td>{l.action}</td>
                <td>{l.targetType}</td>
                <td>{new Date(l.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
