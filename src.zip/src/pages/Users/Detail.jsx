import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Page from "../../layout/Page";
import API from "../../services/api";
import {
  getMotoristaById,
  aprovarMotorista,
  updateMotorista,
} from "../../services/motoristas";

export default function UserDetail() {
  const { id } = useParams();

  const [user, setUser] = useState(null);
  const [motorista, setMotorista] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [trialDate, setTrialDate] = useState("");

  /* ================= LOAD ================= */

  useEffect(() => {
    if (!id) return;

    async function load() {
      try {
        setLoading(true);

        const res = await API.get(`/admin/users/${id}`);
        const userData = res.data?.user || res.data;

        if (!userData) {
          setUser(null);
          return;
        }

        setUser(userData);

        if (userData.role === "motorista") {
          const m = await getMotoristaById(id);
          setMotorista(m);
        }
      } catch (e) {
        console.error("Erro ao carregar usuário:", e);
        setUser(null);
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [id]);

  /* ================= STATUS ONLINE ================= */

  function getOnlineStatus() {
    if (!user?.lastLoginAt) return "Offline";

    const last = new Date(user.lastLoginAt).getTime();
    const now = Date.now();
    const diffMinutes = (now - last) / 1000 / 60;

    return diffMinutes <= 15 ? "Online" : "Offline";
  }

 /* ================= STATUS DA CONTA ================= */

function getCadastroStatusLabel() {
  switch (user?.statusCadastro) {
    case "aprovado":
      return "🟢 Cadastro aprovado";
    case "reprovado":
      return "🔴 Cadastro reprovado";
    case "incompleto":
      return "🟡 Cadastro incompleto";
    default:
      return "—";
  }
}

function getAccountStatusLabel() {
  if (user?.status === "blocked") {
    return "🔴 Bloqueado";
  }
  return "🟢 Ativo";
}

  

  /* ================= STATUS FINANCEIRO (MELHORADO) ================= */

  function getFinancialStatusLabel() {
    switch (user?.subscriptionStatus) {
      case "active":
        return "Ativo";
      case "overdue":
        return "Inadimplente";
      case "trial":
        return "Em período de teste";
      default:
        return "—";
    }
  }

  /* ================= CONTA ================= */

  async function handleUserStatus(status) {
    if (!window.confirm("Confirmar alteração de status do usuário?")) return;

    try {
      setActionLoading(true);

      const res = await API.patch(
        `/admin/users/${id}/status`,
        { status }
      );

      setUser((prev) => ({
        ...prev,
        status: res.data.status || status,
      }));
    } catch (e) {
      console.error(e);
      alert("Erro ao atualizar status do usuário");
    } finally {
      setActionLoading(false);
    }
  }

  /* ================= FINANCEIRO ================= */

  async function handleFinancialAction(action) {
    const confirmMap = {
      activate: "Ativar assinatura deste usuário?",
      "mark-overdue": "Marcar usuário como inadimplente?",
      block: "Bloquear financeiramente este usuário?",
      "extend-trial": "Estender período de teste?",
    };

    if (!window.confirm(confirmMap[action])) return;

    try {
      setActionLoading(true);

      const payload = { action };

      if (action === "extend-trial") {
        if (!trialDate) {
          alert("Selecione a data do trial");
          setActionLoading(false);
          return;
        }
        payload.trialEndsAt = trialDate;
      }

      const res = await API.patch(
        `/admin/users/${id}/financial-status`,
        payload
      );

      setUser((prev) => ({
        ...prev,
        subscriptionStatus: res.data.user.subscriptionStatus,
        trialEndsAt: res.data.user.trialEndsAt,
      }));
    } catch (e) {
      console.error(e);
      alert(
        e.response?.data?.message ||
        "Erro ao executar ação financeira"
      );
    } finally {
      setActionLoading(false);
    }
  }

  /* ================= MOTORISTA ================= */

  async function handleAprovarMotorista() {
    if (!window.confirm("Aprovar motorista?")) return;

    try {
      setActionLoading(true);
      await aprovarMotorista(id);

      setUser((prev) => ({
        ...prev,
        motoristaAprovado: true,
        statusCadastro: "aprovado",
      }));
    } catch (e) {
      console.error(e);
      alert("Erro ao aprovar motorista");
    } finally {
      setActionLoading(false);
    }
  }

  async function handleBloquearMotorista() {
    if (!window.confirm("Bloquear motorista?")) return;

    try {
      setActionLoading(true);
      await updateMotorista(id, {
        aprovado: false,
        status: "reprovado",
      });

      setUser((prev) => ({
        ...prev,
        motoristaAprovado: false,
        statusCadastro: "reprovado",
      }));
    } catch (e) {
      console.error(e);
      alert("Erro ao bloquear motorista");
    } finally {
      setActionLoading(false);
    }
  }

  /* ================= UI ================= */

  if (!id) return <Page title="Usuário">ID inválido</Page>;
  if (loading) return <Page title="Usuário">Carregando…</Page>;
  if (!user) return <Page title="Usuário">Usuário não encontrado</Page>;
  const DOCUMENTS_BY_ROLE = {
  motorista: [
    { key: "cnh", label: "CNH" },
    { key: "vehicle", label: "Documento do veículo" },
  ],
  profissional: [
  {
    key: "identity",
    label: "Documento de identidade",
    required: true,
  },
  {
    key: "certificate",
    label: "Certificado profissional",
    required: false, // 👈 OPCIONAL
  },
],

  empresa: [
    { key: "cnpj", label: "CNPJ" },
    { key: "contratoSocial", label: "Contrato social" },
  ],
};

const roleDocuments = user?.role
  ? DOCUMENTS_BY_ROLE[user.role] || []
  : [];


  return (
    <Page title="Usuário" subtitle={user.email}>
      {/* ================= CONTA ================= */}
      <Card title="Conta do usuário">
        <Grid>
          <Info label="Nome" value={user.name} />
          <Info label="Email" value={user.email} />
          <Info label="Perfil" value={user.role} />
          <Info label="Status da conta" value={getAccountStatus()} />
          <Info label="Status online" value={getOnlineStatus()} />
          <Info label="Verificado" value={user.isVerified ? "Sim" : "Não"} />
          <Info label="Criado em" value={formatDate(user.createdAt)} />
          <Info label="Último login" value={formatDate(user.lastLoginAt)} />
        </Grid>

        <Actions>
          <Action
            label="Bloquear usuário"
            danger
            disabled={actionLoading || user.status === "blocked"}
            onClick={() => handleUserStatus("blocked")}
          />
          <Action
            label="Desbloquear usuário"
            disabled={actionLoading || user.status === "active"}
            onClick={() => handleUserStatus("active")}
          />
        </Actions>
      </Card>

      {/* ================= FINANCEIRO ================= */}
      <Card title="Financeiro">
        <Grid>
          <Info
            label="Status da assinatura"
            value={getFinancialStatusLabel()}
          />
          <Info
            label="Trial até"
            value={formatDate(user.trialEndsAt)}
          />
        </Grid>

        <Actions>
          <Action
            label="Ativar assinatura"
            disabled={actionLoading}
            onClick={() => handleFinancialAction("activate")}
          />
          <Action
            label="Marcar inadimplente"
            warn
            disabled={actionLoading}
            onClick={() => handleFinancialAction("mark-overdue")}
          />
          <Action
            label="Bloquear financeiramente"
            danger
            disabled={actionLoading}
            onClick={() => handleFinancialAction("block")}
          />

          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <input
              type="date"
              value={trialDate}
              onChange={(e) => setTrialDate(e.target.value)}
            />
            <Action
              label="Estender trial"
              disabled={actionLoading}
              onClick={() => handleFinancialAction("extend-trial")}
            />
          </div>
        </Actions>
      </Card>
      
{/* ================= REPUTAÇÃO / USO ================= */}
      <Card title="Reputação e uso">
        <Grid>
          <Info
            label="Avaliação média"
            value={user.rating ? `${user.rating} ⭐` : "—"}
          />
          <Info
            label="Total de avaliações"
            value={user.reviewsCount ?? "—"}
          />
          <Info
            label="Serviços realizados"
            value={user.jobsCompleted ?? "—"}
          />
          <Info
            label="Faturamento no mês"
            value={
              user.monthRevenue
                ? `R$ ${user.monthRevenue.toFixed(2)}`
                : "—"
            }
          />
          <Info
            label="Faturamento total"
            value={
              typeof user.lucroAcumulado === "number"
                ? `R$ ${user.lucroAcumulado.toFixed(2)}`
                : "—"
            }
          />
        </Grid>
      </Card>
      {/* ================= DOCUMENTOS ================= */}
{roleDocuments.length > 0 && (
  <Card title="Documentos">
    <Grid>
      {roleDocuments.map((doc) => {
        const docData = user?.documents?.[doc.key] || {};
        const status = docData.status || "pending";

        return (
          <div key={doc.key}>
            <Info
              label={doc.label}
              value={
                status === "approved"
                  ? "🟢 Aprovado"
                  : status === "rejected"
                  ? "🔴 Reprovado"
                  : "🟡 Pendente"
              }
            />

            <Actions>
              <Action
                label="Aprovar"
                disabled={actionLoading || status === "approved"}
                onClick={() =>
                  handleDocumentAction(doc.key, "approved")
                }
              />
              <Action
                label="Reprovar"
                danger
                disabled={actionLoading || status === "rejected"}
                onClick={() =>
                  handleDocumentAction(doc.key, "rejected")
                }
              />
            </Actions>
          </div>
        );
      })}
    </Grid>
  </Card>
)}


    
      {/* ================= MOTORISTA ================= */}
      {user.role === "motorista" && (
        <Card title="Motorista">
          <Grid>
            <Info label="Status cadastro" value={user.statusCadastro} />
            <Info
              label="Aprovado"
              value={user.motoristaAprovado ? "Sim" : "Não"}
            />
          </Grid>

          <Actions>
            {!user.motoristaAprovado && (
              <Action
                label="Aprovar motorista"
                disabled={actionLoading}
                onClick={handleAprovarMotorista}
              />
            )}

            <Action
              label="Bloquear motorista"
              danger
              disabled={actionLoading}
              onClick={handleBloquearMotorista}
            />
          </Actions>
        </Card>
      )}
    </Page>
  );
}

/* ================= COMPONENTES ================= */

function Card({ title, children }) {
  return (
    <div style={{
      background: "#fff",
      borderRadius: 16,
      padding: 24,
      marginBottom: 24,
      border: "1px solid #E5E7EB",
      boxShadow: "0 1px 2px rgba(0,0,0,0.04)",
    }}>
      <h3 style={{ fontWeight: 700, marginBottom: 16 }}>{title}</h3>
      {children}
    </div>
  );
}

function Grid({ children }) {
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
      gap: 12,
      marginBottom: 16,
    }}>
      {children}
    </div>
  );
}

function Info({ label, value }) {
  return (
    <div style={{ fontSize: 14 }}>
      <div style={{ color: "#6B7280", fontSize: 12 }}>{label}</div>
      <div style={{ fontWeight: 600 }}>{value || "—"}</div>
    </div>
  );
}

function Actions({ children }) {
  return (
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
      {children}
    </div>
  );
}

function Action({ label, onClick, danger, warn, disabled }) {
  let bg = "#2E7D32";
  if (warn) bg = "#F59E0B";
  if (danger) bg = "#DC2626";

  return (
    <button
      disabled={disabled}
      onClick={onClick}
      style={{
        background: bg,
        color: "#fff",
        border: "none",
        padding: "8px 16px",
        borderRadius: 8,
        fontWeight: 700,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.6 : 1,
      }}
    >
      {label}
    </button>
  );
}

function formatDate(date) {
  if (!date) return "—";
  return new Date(date).toLocaleDateString("pt-BR");
}
