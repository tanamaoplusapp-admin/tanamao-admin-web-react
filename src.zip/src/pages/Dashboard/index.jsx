import { useNavigate } from "react-router-dom";
import Page from "../../layout/Page";

function Card({ title, value, subtitle, color, onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: "#FFFFFF",
        border: "1px solid #E5E7EB",
        borderRadius: 14,
        padding: 20,
        cursor: onClick ? "pointer" : "default",
      }}
    >
      <div
        style={{
          fontSize: 13,
          color: "#6B7280",
          fontWeight: 700,
          marginBottom: 6,
        }}
      >
        {title}
      </div>

      <div
        style={{
          fontSize: 28,
          fontWeight: 900,
          color: color || "#14532D",
        }}
      >
        {value ?? "—"}
      </div>

      {subtitle && (
        <div
          style={{
            marginTop: 6,
            fontSize: 13,
            color: "#6B7280",
          }}
        >
          {subtitle}
        </div>
      )}
    </div>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();

  // por enquanto estático
  const systemHealth = "ok"; // ok | warning | critical

  const healthMap = {
    ok: {
      label: "Sistema saudável",
      color: "#15803D",
    },
    warning: {
      label: "Atenção",
      color: "#92400E",
    },
    critical: {
      label: "Problema crítico",
      color: "#DC2626",
    },
  };

  return (
    <Page
      title="Central Tanamão+"
      subtitle="Visão geral da operação e do sistema"
    >
      <div style={grid}>
        <Card
          title="Saúde do sistema"
          value={healthMap[systemHealth].label}
          color={healthMap[systemHealth].color}
          subtitle="Backend, app e pagamentos"
          onClick={() => navigate("/bugs")}
        />

        <Card
          title="Usuários"
          value="—"
          subtitle="ativos / bloqueados"
          onClick={() => navigate("/users")}
        />

        <Card
          title="Pedidos"
          value="—"
          subtitle="em andamento"
          onClick={() => navigate("/orders")}
        />

        <Card
          title="Financeiro"
          value="—"
          subtitle="trial • ativos • inadimplentes"
          onClick={() => navigate("/finance")}
        />

        <Card
          title="Conversas"
          value="—"
          subtitle="aguardando resposta"
          onClick={() => navigate("/conversations")}
        />

        <Card
          title="Bugs críticos"
          value="—"
          subtitle="erros prioritários"
          color="#DC2626"
          onClick={() => navigate("/bugs")}
        />
      </div>
    </Page>
  );
}

/* ================= STYLES ================= */

const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
  gap: 16,
};
