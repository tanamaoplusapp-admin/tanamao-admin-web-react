import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Page from "../../layout/Page";
import { getOrders } from "../../services/orders";

export default function Orders() {
  const navigate = useNavigate();

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function load() {
      try {
        const data = await getOrders();
        setOrders(data || []);
      } catch (err) {
        setError(
          err.response?.data?.message ||
            err.message ||
            "Erro ao carregar pedidos"
        );
      } finally {
        setLoading(false);
      }
    }

    load();
  }, []);

  if (loading) {
    return <Page title="Pedidos">Carregando pedidos…</Page>;
  }

  if (error) {
    return <Page title="Pedidos">{error}</Page>;
  }

  return (
    <Page
      title="Pedidos"
      subtitle="Pedidos realizados no Tanamão+"
    >
      <div style={tableWrapper}>
        <table style={table}>
          <thead>
            <tr>
              <th style={th}>ID</th>
              <th style={th}>Usuário</th>
              <th style={th}>Status</th>
              <th style={th}>Valor</th>
              <th style={th}>Criado em</th>
              <th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id || o._id}>
                <td style={td}>{o.id || o._id}</td>
                <td style={td}>{o.user?.email || "-"}</td>
                <td style={td}>{o.status}</td>
                <td style={td}>
                  {o.total
                    ? `R$ ${Number(o.total).toFixed(2)}`
                    : "—"}
                </td>
                <td style={td}>
                  {o.createdAt
                    ? new Date(o.createdAt).toLocaleString()
                    : "—"}
                </td>
                <td style={{ ...td, textAlign: "right" }}>
                  <button
                    onClick={() =>
                      navigate(`/orders/${o.id || o._id}`)
                    }
                    style={btn}
                  >
                    Ver detalhe
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {orders.length === 0 && (
          <div style={{ padding: 20 }}>
            Nenhum pedido encontrado.
          </div>
        )}
      </div>
    </Page>
  );
}

/* ================= STYLES ================= */

const tableWrapper = {
  background: "#FFFFFF",
  border: "1px solid #E5E7EB",
  borderRadius: 12,
  overflow: "hidden",
};

const table = {
  width: "100%",
  borderCollapse: "collapse",
};

const th = {
  padding: 12,
  textAlign: "left",
  fontSize: 13,
  fontWeight: 700,
  background: "#F3F4F6",
  color: "#374151",
};

const td = {
  padding: 12,
  borderTop: "1px solid #E5E7EB",
  fontSize: 14,
  color: "#111827",
};

const btn = {
  background: "#14532D",
  color: "#FFFFFF",
  border: "none",
  padding: "6px 12px",
  borderRadius: 8,
  fontWeight: 700,
  cursor: "pointer",
};
