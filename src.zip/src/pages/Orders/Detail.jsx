import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getOrderById } from "../../services/orders";

export default function OrderDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function load() {
      try {
        const data = await getOrderById(id);
        setOrder(data);
      } catch (err) {
        setError(
          err.response?.data?.message ||
            err.message ||
            "Erro ao carregar pedido"
        );
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [id]);

  if (loading) {
    return <div style={page}>Carregando pedido…</div>;
  }

  if (error) {
    return <div style={page}>{error}</div>;
  }

  if (!order) {
    return <div style={page}>Pedido não encontrado</div>;
  }

  return (
    <div style={page}>
      <button onClick={() => navigate("/orders")} style={backBtn}>
        ← Voltar
      </button>

      <h2 style={title}>Detalhe do pedido</h2>

      <div style={card}>
        <Info label="ID" value={order.id || order._id} />
        <Info label="Usuário" value={order.user?.email} />
        <Info label="Status" value={order.status} />
        <Info
          label="Valor total"
          value={
            order.total
              ? `R$ ${Number(order.total).toFixed(2)}`
              : "—"
          }
        />
        <Info
          label="Criado em"
          value={
            order.createdAt
              ? new Date(order.createdAt).toLocaleString()
              : "—"
          }
        />
      </div>
    </div>
  );
}

function Info({ label, value }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <strong>{label}:</strong>
      <div>{value || "—"}</div>
    </div>
  );
}

/* ================= STYLES ================= */

const page = {
  background: "#F9FAFB",
  color: "#111827",
  minHeight: "100vh",
  padding: 24,
};

const backBtn = {
  background: "transparent",
  border: "none",
  color: "#14532D",
  fontWeight: 700,
  marginBottom: 16,
  cursor: "pointer",
};

const title = {
  fontSize: 22,
  fontWeight: 900,
  color: "#14532D",
  marginBottom: 20,
};

const card = {
  background: "#FFFFFF",
  border: "1px solid #E5E7EB",
  borderRadius: 12,
  padding: 20,
  maxWidth: 520,
};
