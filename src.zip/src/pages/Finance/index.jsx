import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../../services/api";

const Card = ({ title, value, subtitle, color = "#2E7D32" }) => (
  <div
    style={{
      background: "#fff",
      borderRadius: 14,
      padding: 16,
      border: "1px solid #E5E7EB",
      minWidth: 180,
    }}
  >
    <div style={{ fontSize: 14, color: "#64748B", fontWeight: 700 }}>
      {title}
    </div>
    <div
      style={{
        fontSize: 26,
        fontWeight: 900,
        color,
        marginTop: 6,
      }}
    >
      {value}
    </div>
    {subtitle && (
      <div style={{ marginTop: 6, fontSize: 13, color: "#6B7280" }}>
        {subtitle}
      </div>
    )}
  </div>
);

export default function Finance() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState(null);

  const [resumo, setResumo] = useState({
    emTrial: 0,
    ativos: 0,
    inadimplentes: 0,
  });

  const [receita, setReceita] = useState({
    today: 0,
    week: 0,
    month: 0,
  });

  useEffect(() => {
    async function carregarDados() {
      try {
        setLoading(true);
        setErro(null);

        const [mensalidadeRes, financeRes] = await Promise.all([
          API.get("/central-mensalidade/resumo"),
          API.get("/finance/summary"),
        ]);

        if (mensalidadeRes.data?.data) {
          setResumo({
            emTrial: mensalidadeRes.data.data.emTrial || 0,
            ativos: mensalidadeRes.data.data.ativos || 0,
            inadimplentes: mensalidadeRes.data.data.inadimplentes || 0,
          });
        }

        if (financeRes.data) {
          setReceita({
            today: financeRes.data.today || 0,
            week: financeRes.data.week || 0,
            month: financeRes.data.month || 0,
          });
        }
      } catch (e) {
        console.error("Erro ao carregar financeiro:", e);
        setErro("Não foi possível carregar os dados financeiros.");
      } finally {
        setLoading(false);
      }
    }

    carregarDados();
  }, []);

  return (
    <div style={{ padding: 24, background: "#F9FAFB", minHeight: "100vh" }}>
      {/* TOPO */}
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 900, color: "#1B5E20" }}>
          Financeiro
        </h1>
        <p style={{ color: "#64748B" }}>
          Visão geral financeira do Tanamão+
        </p>
      </div>

      {loading && <p>Carregando dados financeiros…</p>}

      {erro && (
        <div style={{ color: "#DC2626", marginBottom: 16 }}>{erro}</div>
      )}

      {!loading && !erro && (
        <>
          {/* GRID DE CARDS */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
              gap: 16,
              marginBottom: 32,
            }}
          >
            <Card
              title="Usuários em trial"
              value={resumo.emTrial}
              subtitle="4 meses grátis"
              color="#1565C0"
            />

            <Card
              title="Usuários ativos"
              value={resumo.ativos}
              subtitle="Pagantes"
              color="#2E7D32"
            />

            <Card
              title="Inadimplentes"
              value={resumo.inadimplentes}
              subtitle="Pagamento pendente"
              color="#EF6C00"
            />

            <Card
              title="Receita do mês"
              value={`R$ ${receita.month.toFixed(2)}`}
              subtitle="Pagamentos aprovados"
              color="#1B5E20"
            />
          </div>

          {/* AÇÕES RÁPIDAS */}
          <div
            style={{
              background: "#fff",
              borderRadius: 14,
              padding: 20,
              border: "1px solid #E5E7EB",
            }}
          >
            <h3 style={{ marginBottom: 12, color: "#1B5E20" }}>
              Ações rápidas
            </h3>

            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <button
                onClick={() => navigate("/users")}
                style={btn}
              >
                Ver usuários
              </button>

              <button
                onClick={() => navigate("/finance/transactions")}
                style={btn}
              >
                Ver transações
              </button>

              <button
                onClick={() => navigate("/finance/reconciliation")}
                style={btn}
              >
                Conciliação
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

const btn = {
  background: "#2E7D32",
  color: "#fff",
  border: "none",
  borderRadius: 10,
  padding: "10px 16px",
  fontWeight: 700,
  cursor: "pointer",
};
