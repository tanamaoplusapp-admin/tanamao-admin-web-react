import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  getFinanceSummary,
  getMensalidadesResumo,
} from "../../services/finance";

const Card = ({ title, value, subtitle, color = "#2E7D32" }) => (
  <div
    style={{
      background: "#fff",
      borderRadius: 14,
      padding: 16,
      border: "1px solid #E5E7EB",
    }}
  >
    <div style={{ fontSize: 14, color: "#64748B", fontWeight: 700 }}>
      {title}
    </div>
    <div
      style={{
        fontSize: 26,
        fontWeight: 900,
        color,
        marginTop: 6,
      }}
    >
      {value ?? "—"}
    </div>
    {subtitle && (
      <div style={{ marginTop: 6, fontSize: 13, color: "#6B7280" }}>
        {subtitle}
      </div>
    )}
  </div>
);

export default function FinanceOverview() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState(null);

  const [resumo, setResumo] = useState({
    emTrial: null,
    ativos: null,
    inadimplentes: null,
  });

  const [receita, setReceita] = useState({
    month: null,
  });

  useEffect(() => {
    async function carregar() {
      try {
        setLoading(true);
        setErro(null);

        const [mensalidadeRes, financeRes] = await Promise.all([
          getMensalidadesResumo(),
          getFinanceSummary(),
        ]);

        if (mensalidadeRes?.data) {
          setResumo({
            emTrial: mensalidadeRes.data.emTrial ?? null,
            ativos: mensalidadeRes.data.ativos ?? null,
            inadimplentes: mensalidadeRes.data.inadimplentes ?? null,
          });
        }

        if (financeRes) {
          setReceita({
            month: financeRes.month ?? null,
          });
        }
      } catch (e) {
        console.error("Erro ao carregar financeiro:", e);
        setErro("Financeiro ainda não disponível.");
      } finally {
        setLoading(false);
      }
    }

    carregar();
  }, []);

  return (
    <div style={{ padding: 24, background: "#F9FAFB", minHeight: "100vh" }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 900, color: "#1B5E20" }}>
          Financeiro
        </h1>
        <p style={{ color: "#64748B" }}>
          Visão geral financeira do Tanamão+
        </p>
      </div>

      {loading && <p>Carregando dados financeiros…</p>}
      {erro && <p style={{ color: "#DC2626" }}>{erro}</p>}

      {!loading && !erro && (
        <>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
              gap: 16,
              marginBottom: 32,
            }}
          >
            <Card
              title="Usuários em trial"
              value={resumo.emTrial}
              subtitle="4 meses grátis"
              color="#1565C0"
            />

            <Card
              title="Usuários ativos"
              value={resumo.ativos}
              subtitle="Pagantes"
              color="#2E7D32"
            />

            <Card
              title="Inadimplentes"
              value={resumo.inadimplentes}
              subtitle="Pagamento pendente"
              color="#EF6C00"
            />

            <Card
              title="Receita do mês"
              value={
                receita.month !== null
                  ? `R$ ${receita.month.toFixed(2)}`
                  : "—"
              }
              subtitle="Pagamentos aprovados"
              color="#1B5E20"
            />
          </div>

          <div
            style={{
              background: "#fff",
              borderRadius: 14,
              padding: 20,
              border: "1px solid #E5E7EB",
            }}
          >
            <h3 style={{ marginBottom: 12, color: "#1B5E20" }}>
              Ações rápidas
            </h3>

            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <button onClick={() => navigate("/finance/users")} style={btn}>
                Usuários
              </button>
              <button
                onClick={() => navigate("/finance/transactions")}
                style={btn}
              >
                Transações
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

const btn = {
  background: "#2E7D32",
  color: "#fff",
  border: "none",
  borderRadius: 10,
  padding: "10px 16px",
  fontWeight: 700,
  cursor: "pointer",
};
